#!/usr/bin/env bash
# /opt/autograder.sh - rebuild the LAB 10 & 11 targets from nothing and harden
# them. Noninteractive; uses only software already on lab11-ctrl; stops with a
# nonzero status the moment any step fails.
set -euo pipefail

# TODO: set this probably
# PROJECT_DIR=??

# sudo and non-login shells can leave /usr/local/bin (where the Ansible
# commands live) off the PATH.
export PATH=/usr/local/bin:/usr/bin:/usr/sbin:/bin:$PATH
export ANSIBLE_VAULT_PASSWORD_FILE=/opt/password
export ANSIBLE_CONFIG=$PROJECT_DIR/ansible.cfg
export ANSIBLE_FORCE_COLOR=0

# TODO: run your playbooks here for the autograder to analyze
# hint: it's probably helpful to cd to the directory with your playbooks
